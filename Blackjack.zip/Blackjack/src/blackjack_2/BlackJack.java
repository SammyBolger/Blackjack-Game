package blackjack_2;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class BlackJack {

    private ArrayList<Card> deck;
    public ArrayList<Card> GetDeck() {return deck;}
    public void SetDeck(ArrayList<Card> deck) {this.deck = deck;}
    
    private Card hiddenCard;
    public Card GethiddenCard() {return hiddenCard;}
    public void SetHiddenCard(Card hiddenCard) {this.hiddenCard = hiddenCard;}
    
    private ArrayList<Card> dealerHand;
    public ArrayList<Card> GetDealerHand() {return dealerHand;}
    public void SetDealerHand(ArrayList<Card> dealerHand) {this.dealerHand = dealerHand;}

    private int dealerSum;
    public int GetDealerSum() {return dealerSum;}
    public void SetDealerSum(int dealerSum) {this.dealerSum = dealerSum;}
    
    private int dealerAceCount;
    public int GetDealerAceCount() {return dealerAceCount;}
    public void SetDealerAceCount(int dealerAceCount) {this.dealerAceCount = dealerAceCount;}
    
    private ArrayList<Card> playerHand;
    public ArrayList<Card> GetPlayerHand() {return playerHand;}
    public void SetPlayerHand(ArrayList<Card> playerHand) {this.playerHand = playerHand;}
    
    private int playerSum = 0;
    public int GetPlayerSum() {return playerSum;}
    public void SetPlayerSum(int playerSum) {this.playerSum = playerSum;}
    
    private int playerAceCount = 0;
    public int GetPlayerAceCount() {return playerAceCount;}
    public void SetPlayerAceCount(int playerAceCount) {this.playerAceCount = playerAceCount;}
    
    private int dealerShow;
    public int GetDealerShow() {return dealerShow;}
    public void SetDealerShow(int dealerShow) {this.dealerShow = dealerShow;}
    
    Random random = new Random();

    private int boardWidth = 1200;
    private int boardHeight = 700;

    private int cardWidth = 150;
    private int cardHeight = 210;

    private JFrame frame = new JFrame("Black Jack");
    private JPanel gamePanel = new JPanel() {
    @Override
    public void paintComponent(Graphics g) {
        //Makes the background be Background1.jpeg
        super.paintComponent(g);
        Image backgroundImage = new ImageIcon(getClass().getResource("./Backround1.jpeg")).getImage();
        g.drawImage(backgroundImage, 0, 0, 1200, 700, null);
        try {
            // Draw hidden card
            Image hiddenCardImage = new ImageIcon(getClass().getResource("./cards/BACK.png")).getImage();
            if (!stayButton.isEnabled()) {
                hiddenCardImage = new ImageIcon(getClass().getResource(hiddenCard.getImagePath())).getImage();
            }
            g.drawImage(hiddenCardImage, 20, 20, cardWidth, cardHeight, null);

            // Make dealer's hand
            for (int i = 0; i < dealerHand.size(); i++) {
                Card card = dealerHand.get(i);
                Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
                g.drawImage(cardImg, cardWidth + 25 + (cardWidth + 5) * i, 20, cardWidth, cardHeight, null);
            }

            // Make player's hand
            for (int i = 0; i < playerHand.size(); i++) {
                Card card = playerHand.get(i);
                Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
                g.drawImage(cardImg, 20 + (cardWidth + 5) * i, 320, cardWidth, cardHeight, null);
            }

            // Dealer value on the right side
            g.setFont(new Font("Arial", Font.BOLD, 25));
            g.setColor(Color.white);

            // Get the value of the faced-up card or total value if the dealer has stayed
            if (!dealerHand.isEmpty()) {
                Card facedUpCard = dealerHand.get(0);
                dealerShow = facedUpCard.getValue();
            } 

            // Draw player value on the right side
            g.setFont(new Font("Arial", Font.BOLD, 25));
            g.setColor(Color.white);
            g.drawString("Player Value: " + playerSum, boardWidth - 230, 450);

            if (!stayButton.isEnabled()) {
                dealerSum = reduceDealerAce();
                playerSum = reducePlayerAce();
                System.out.println("STAY: ");
                System.out.println(dealerSum);
                System.out.println(playerSum);
                dealerShow = dealerSum;

                String message = "";
                if (dealerSum > 21) {
                    message = "You Win!";
                    playerBalance += currentBet * 2;
                } else if (playerSum == dealerSum) {
                    message = "Push";
                    playerBalance += currentBet;
                } else if (playerSum > dealerSum) {
                    message = "You Win!";
                    playerBalance += currentBet * 2;
                } else if (playerSum < dealerSum) {
                    message = "You Lose!";
                }

                

                g.setFont(new Font("Arial", Font.BOLD, 50));
                g.setColor(Color.white);
                g.drawString(message, 475, 300);  // Adjust the y-coordinate
            }

            if (playerSum > 21) {
                stayButton.setEnabled(false);
                String message = "You Lose!";
                g.setFont(new Font("Arial", Font.BOLD, 50));
                g.setColor(Color.white);
                g.drawString(message, 475, 300);  // Adjust the y-coordinate
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        balanceLabel.setText("Balance: $" + playerBalance);
        g.setFont(new Font("Arial", Font.BOLD, 25));
        g.drawString("Dealer Value: " + dealerShow, boardWidth - 230, 150);
    }
};
    private JPanel buttonPanel = new JPanel();
    private JButton hitButton = new JButton("Hit");
    private JButton stayButton = new JButton("Stay");
    private JButton replayButton = new JButton("Play Again");
    private JButton homeButton = new JButton("Home");

    

    private int playerBalance = 1000;
    private int currentBet = 0;
    private JLabel balanceLabel = new JLabel("Balance: $" + playerBalance);


    /**
     * Makes the whole window that the game play is in
     * Got help from KennyYipCoding
     */
    public void makeFrame() {
        frame.setVisible(true);
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        gamePanel.setLayout(new BorderLayout());
        gamePanel.setBackground(new Color(53, 101, 77));
        frame.add(gamePanel);

        hitButton.setFocusable(false);
        buttonPanel.add(hitButton);
        stayButton.setFocusable(false);
        buttonPanel.add(stayButton);
        replayButton.setFocusable(false);
        buttonPanel.add(replayButton);
        homeButton.setFocusable(false);
        buttonPanel.add(homeButton);
        buttonPanel.add(balanceLabel); // Add balance label to the button panel

        frame.add(buttonPanel, BorderLayout.SOUTH);

        hitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Card card = deck.remove(deck.size() - 1);
                playerSum += card.getValue();
                playerAceCount += card.isAce() ? 1 : 0;
                playerHand.add(card);
                if (reducePlayerAce() > 21) {
                    hitButton.setEnabled(false);
                }
                gamePanel.repaint();
            }
        });

        replayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                replayGame();
                gamePanel.repaint();
            }
        });

        homeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Home home1 = new Home();
                home1.setVisible(true);
                home1.setLocationRelativeTo(null);
                gamePanel.repaint();
                frame.dispose();
            }
        });

        stayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                hitButton.setEnabled(false);
                stayButton.setEnabled(false);

                while (dealerSum < 17) {
                    Card card = deck.remove(deck.size() - 1);
                    dealerSum += card.getValue();
                    dealerAceCount += card.isAce() ? 1 : 0;
                    dealerHand.add(card);
                }
                gamePanel.repaint();
            }
        });

        gamePanel.repaint();
    }
    
    /**
     * Helper method to start the game
     */
    public void gamePlay() {
        startGame();
        makeFrame();
    }
    
    /**
     * Starts the BlackJack Game, makes each player's hand
     */
    public void startGame() {
        buildDeck();
        shuffleDeck();

        dealerHand = new ArrayList<Card>();
        dealerSum = 0;
        dealerAceCount = 0;

        hiddenCard = deck.remove(deck.size() - 1);
        dealerSum += hiddenCard.getValue();
        dealerAceCount += hiddenCard.isAce() ? 1 : 0;

        Card card = deck.remove(deck.size() - 1);
        dealerSum += card.getValue();
        dealerAceCount += card.isAce() ? 1 : 0;
        dealerHand.add(card);

        System.out.println("Dealer:");
        System.out.println(hiddenCard);
        System.out.println(dealerHand);
        System.out.println(dealerSum);
        System.out.println(dealerAceCount);

        playerHand = new ArrayList<Card>();
        playerSum = 0;
        playerAceCount = 0;

        for (int i = 0; i < 2; i++) {
            card = deck.remove(deck.size() - 1);
            playerSum += card.getValue();
            playerAceCount += card.isAce() ? 1 : 0;
            playerHand.add(card);
        }

        currentBet = getPlayerBet();
        playerBalance -= currentBet;

        System.out.println("Player Hand:");
        System.out.println(playerHand);
        System.out.println(playerSum);
        System.out.println(playerAceCount);
    }

    /**
     * Same as startGame() except it enables the buttons again to allow playing repeatedly 
     */
    public void replayGame() {
        stayButton.setEnabled(true);
        hitButton.setEnabled(true);

        shuffleDeck();
        frame.repaint();
        gamePanel.repaint();
        gamePanel.revalidate();

        dealerHand = new ArrayList<Card>();
        dealerSum = 0;
        dealerAceCount = 0;

        hiddenCard = deck.remove(deck.size() - 1);
        dealerSum += hiddenCard.getValue();
        dealerAceCount += hiddenCard.isAce() ? 1 : 0;

        Card card = deck.remove(deck.size() - 1);
        dealerSum += card.getValue();
        dealerAceCount += card.isAce() ? 1 : 0;
        dealerHand.add(card);

        System.out.println("Dealer:");
        System.out.println(hiddenCard);
        System.out.println(dealerHand);
        System.out.println(dealerSum);
        System.out.println(dealerAceCount);

        playerHand = new ArrayList<Card>();
        playerSum = 0;
        playerAceCount = 0;

        for (int i = 0; i < 2; i++) {
            card = deck.remove(deck.size() - 1);
            playerSum += card.getValue();
            playerAceCount += card.isAce() ? 1 : 0;
            playerHand.add(card);
        }

        currentBet = getPlayerBet();
        playerBalance -= currentBet;

        System.out.println("Player Hand:");
        System.out.println(playerHand);
        System.out.println(playerSum);
        System.out.println(playerAceCount);
    }

    /**
     * Gets the bet the player put it
     * @return the bet of the player
     */
    private int getPlayerBet() {
        String betInput = JOptionPane.showInputDialog("Enter your bet:");
        int bet = Integer.parseInt(betInput);

        if (bet <= 0 || bet > playerBalance) {
            JOptionPane.showMessageDialog(null, "Invalid bet. Please enter a valid bet.");            
            return getPlayerBet();
        }

        return bet;
    }
    
    /**
     * Builds the deck of cards that the players use
     */
    public void buildDeck() {
        deck = new ArrayList<Card>();
        String[] values = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        String[] types = {"C", "D", "H", "S"};

        for (int i = 0; i < types.length; i++) {
            for (int j = 0; j < values.length; j++) {
                Card card = new Card(values[j], types[i]);
                deck.add(card);
            }
        }

        System.out.println("Build Deck:");
        System.out.println(deck);
    }
    
    /**
     * Shuffles the deck of cards
     */
    public void shuffleDeck() {
        for (int i = 0; i < deck.size(); i++) {
            int j = random.nextInt(deck.size());
            Card currCard = deck.get(i);
            Card randomCard = deck.get(j);
            deck.set(i, randomCard);
            deck.set(j, currCard);
        }

        System.out.println("AFTER SHUFFLE");
        System.out.println(deck);
    }
    
    /**
     * takes the players ace and reduces it to 1 if needed
     * @return it returns the new player count with 10 less since the ace is now only worth 1
     */
    public int reducePlayerAce() {
        while (playerSum > 21 && playerAceCount > 0) {
            playerSum -= 10;
            playerAceCount -= 1;
        }
        return playerSum;
    }

    /**
     * takes the dealers ace and reduces it to 1 if needed
     * @return it returns the new dealer count with 10 less since the ace is now only worth 1
     */
    public int reduceDealerAce() {
        while (dealerSum > 21 && dealerAceCount > 0) {
            dealerSum -= 10;
            dealerAceCount -= 1;
        }
        return dealerSum;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BlackJack game = new BlackJack();
            game.gamePlay();
        });
    }
}
