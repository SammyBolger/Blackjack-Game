/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjack_2;

/**
 *
 * @author elimach
 */
public class Card {

    private String value;
    public int getValue() {
        if ("AJQK".contains(value)) { //AJQK
            if (value == "A") {
                return 11;
            }
            return 10;
        }
        return Integer.parseInt(value); //2-10
    }
    public void SetValue(String value) {this.value = value;}
    
    private String type;
    public String GetType() {return type;}
    public void SetType(String type) {this.type = type;}
    
    //Card Constructor
    Card(String value, String type) {
        this.value = value;
        this.type = type;
    }
    
    //Default constructor 
    Card() {}
    
    /**
     * Turns the card into a string
     * @return the value-type which then can be used to get a card image
     */
    public String toString() {
        return value + "-" + type;
    }
    
    
    /**
     * Checks if the card is an Ace
     * @return it returns the value of an Ace if it's true
     */
    public boolean isAce() {
        return value == "A";
    }
    
    /**
     * gets the image path of the card to be used to get an image of it
     * @return Returns the string that is the image path in the folder of cards
     */
    public String getImagePath() {
        return "./cards/" + toString() + ".png";
    }
}
