/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package blackjack_2;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author elimach
 */
public class CardTest {
    
    public CardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
    System.setErr(new PrintStream(errContent));
}

    @After
    public void restoreStreams() {
    System.setOut(originalOut);
    System.setErr(originalErr);
    }
    
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    /**
     * Test of toString method, of class Card.
     */
    @Test
    public void testToString() {
        Card c = new Card();
        c.SetType("C");
        c.SetValue("8");
        
        c.toString();
        String expected = "8-C";
        
        assertEquals(expected,c.toString());
    }
    
    /**
     * Test of toString method, of class Card.
     */
    @Test
    public void testGetValue() {
        Card c = new Card();
        c.SetValue("A");
        
        int expected = 11;
        
        assertEquals(expected,c.getValue());
    }

    /**
     * Test of isAce method, of class Card.
     */
    @Test
    public void testIsAce() {
        Card c = new Card();
        c.SetValue("A");
        
        boolean expected = true;
        
        assertEquals(expected,c.isAce());
    }

    /**
     * Test of getImagePath method, of class Card.
     */
    @Test
    public void testGetImagePath() {
        Card c = new Card();
        c.SetType("C");
        c.SetValue("8");
        
        
        String expected = "./cards/8-C.png";
        
        assertEquals(expected,c.getImagePath());
    }
    
}
