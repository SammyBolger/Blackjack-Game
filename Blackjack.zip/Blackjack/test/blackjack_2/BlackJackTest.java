/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package blackjack_2;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import javax.swing.JButton;
import javax.swing.JFrame;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author elimach
 */
public class BlackJackTest {
    
    public BlackJackTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
    System.setErr(new PrintStream(errContent));
}

    @After
    public void restoreStreams() {
    System.setOut(originalOut);
    System.setErr(originalErr);
    }


    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;
    
    
    //I talked to you about how some of the tests weren't working and you said it's fine if they don't work as long as
    //it is clear what we are trying to test
    
    
    /**
     * Test of makeFrame method, testing to see if the frame is visible when the method is started
     */
    @Test
    public void testMakeFrame_TestIfFrameIsVisible() {
        JFrame frame = new JFrame(); 
        frame.setVisible(true);
        
        assertTrue("Frame should be visible", frame.isVisible());     
    }
    

    /**
     * Test of startGame method, Test if the player hand equals what it should 
     */
    @Test
    public void testStartGame_TestOutput() {
        BlackJack b = new BlackJack();
        b.SetDealerSum(17);
        b.SetDealerAceCount(0);
        Card hiddenCard = new Card("7","D");
        
        b.SetPlayerSum(20);
        b.SetPlayerAceCount(0);
        
        String expected = "Dealer Hand:\n"
                + hiddenCard
                + "Q-H\n"
                + "17\n"
                + "0\n"
                +"Player Hand:\n"
                +"Q-H, Q-D\n"
                +"20\n"
                +"0";
        
        assertEquals(expected,outContent.toString());
    }

    /**
     * Test of replayGame method, test to make the the stay button is enabled after replaying 
     * since that is how the game is able to keep playing over and over again
     */
    @Test
    public void testReplayGame_stayButton_isEnabled() {
        JButton stayButton = new JButton("Stay");
        
        stayButton.setEnabled(true);
        assertTrue("Button should be enabled", stayButton.isEnabled());
    }

    /**
     * Test of buildDeck method, make sure the buildDeck() method makes the standard deck
     */
    @Test
    public void testBuildDeck_BuildsStandardDeck() {
        BlackJack bj = new BlackJack();
        
        String expected = "Build Deck:\n[A-C, 2-C, 3-C, 4-C, 5-C, 6-C, 7-C, 8-C, 9-C, 10-C, J-C, Q-C, K-C, A-D, 2-D, 3-D, 4-D, 5-D, 6-D, 7-D, 8-D, 9-D, 10-D, J-D, Q-D, K-D, A-H, 2-H, 3-H, 4-H, 5-H, 6-H, 7-H, 8-H, 9-H, 10-H, J-H, Q-H, K-H, A-S, 2-S, 3-S, 4-S, 5-S, 6-S, 7-S, 8-S, 9-S, 10-S, J-S, Q-S, K-S] ";
        bj.buildDeck();
        
        assertEquals(expected,outContent.toString());
    }

    /**
     * Test of shuffleDeck method, checking to make sure the shuffled deck doesn't not equal the non-shuffled deck
     */
    @Test
    public void testShuffleDeck_DeckDoesNotEqualStandardDeck() {
        BlackJack b = new BlackJack();
        
        
        String actualValue = outContent.toString();
        String expectedValue = "A-C, 2-C, 3-C, 4-C, 5-C, 6-C, 7-C, 8-C, 9-C, 10-C, J-C, Q-C, K-C, A-D, 2-D, 3-D, 4-D, 5-D, 6-D, 7-D, 8-D, 9-D, 10-D, J-D, Q-D, K-D, A-H, 2-H, 3-H, 4-H, 5-H, 6-H, 7-H, 8-H, 9-H, 10-H, J-H, Q-H, K-H, A-S, 2-S, 3-S, 4-S, 5-S, 6-S, 7-S, 8-S, 9-S, 10-S, J-S, Q-S, K-S";
        assertNotEquals("Values should not be equal", expectedValue, actualValue);
    }

    /**
     * Test of reducePlayerAce method, checking to see if when player sum is over 21 and they have an ace, their 
     * sum gets reduced down by ten
     */
    @Test
    public void testReducePlayerAce_PlayerSum22_AceCount1() {
        BlackJack b = new BlackJack();
        
        b.SetPlayerAceCount(1);
        b.SetPlayerSum(22);
        
        int expected = 12;
        
        assertEquals(expected,b.reducePlayerAce());
    }

    /**
     * Test of reduceDealerAce method, checking to see if when dealer sum is over 21 and they have an ace their 
     * sum gets reduced down by ten
     */
    @Test
    public void testReduceDealerAce_DealerSum22_AceCount1() {
        BlackJack b = new BlackJack();
        
        b.SetDealerAceCount(1);
        b.SetDealerSum(22);
        
        int expected = 12;
        
        assertEquals(expected,b.reduceDealerAce());
    }
    
}
